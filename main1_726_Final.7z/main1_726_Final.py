# importing openpyxl module
import os

import openpyxl
import xlsxwriter
import datetime
import pandas

# Give the location of the file
path = "C:/Users/akalleda/PycharmProjects/excelsfilter/trials.xlsx"  # source xl path

# workbook object is created
wb_obj = openpyxl.load_workbook(path)

sheet_obj = wb_obj.active
max_col = sheet_obj.max_column
max_row = sheet_obj.max_row
l = []  # Trial list
el = []  # other list
pl = []  # pipeline list
al = []  # active list
closed_list = []  # closed list
newtrial_list = []  # new trial list
lab_list = []  # lab list
currentweek=datetime.datetime.now().isocalendar().week
#print("current week is",currentweek)
b = "Trial"  # variable to filter Trial Opportunity Type=trial
# Loop will print all columns name
for i in range(1, max_row + 1):
    for j in range(1, max_col + 1):
        cell_obj = sheet_obj.cell(i, column=j)

        #print(cell_obj.value)
        # Trial pipeline
        #date_time_obj=0

        if (cell_obj.value) == b:
            for k in range(1, max_col + 1):
                #for m in range(1, max_col + 1):
                l.append((sheet_obj.cell(i, k)).value)
        # Pipeline
        pl1 = ["0 - Concept / Interested", "1 - Planning"]
        if (cell_obj.value) == b:
            for k in range(1, max_col + 1):
                if (sheet_obj.cell(i, k).value in pl1):
                    for m in range(1, max_col + 1):
                        pl.append((sheet_obj.cell(i, m)).value)

        # Active List
        al1 = ["2 - Submitted", "3 - Shipped / Setup / Waiting for Customer", "4 - Active"]
        if (cell_obj.value) == b:
            for k in range(1, max_col + 1):
                if (sheet_obj.cell(i, k).value in al1):
                    for m in range(1, max_col + 1):
                        al.append((sheet_obj.cell(i, m)).value)
        # Closed
        cl1 = ["5 - Closed - Non-Trial Completed"]
        if (cell_obj.value) == b:
            for k in range(1, max_col + 1):
                if (sheet_obj.cell(i, k).value in cl1):
                    for m in range(1, max_col + 1):
                        closed_list.append((sheet_obj.cell(i, m)).value)
        # New Trials
        nt1 = ["1 - Planning", "2 - Submitted", "3 - Shipped / Setup / Waiting for Customer"]
        if (cell_obj.value) == b:
            for k in range(1, max_col + 1):

                #date_time_obj = datetime.datetime.strptime(str(sheet_obj.cell(i, k+4).value), '%m/%d/%Y')
                #print(date_time_obj.date().isocalendar().week)
                if (sheet_obj.cell(i, k).value in nt1): #and date_time_obj.date().isocalendar().week > ((datetime.datetime.now().isocalendar().week) - 3) and int(date_time_obj.date().isocalendar().week) < ((datetime.datetime.now().isocalendar().week) + 1):
                    for m in range(1, max_col + 1):
                        #print("manohar", sheet_obj.cell(i, m + 4).value)
                        newtrial_list.append((sheet_obj.cell(i, m)).value)

        # Labs
        lt1 = ["Customer Labs", "Partner Labs", "CSAT", "Customer Probes", "Other", "Early Access", "VAS", "IOT", "FOA", "Delivery", "Transition"]
        lt2 = ["2 - Submitted", "3 - Shipped / Setup / Waiting for Customer", "4 - Active"]
        if(cell_obj.value) in lt1:
            for k in range(1, max_col + 1):
                if (sheet_obj.cell(i, k).value in lt2):
                    for m in range(1, max_col + 1):
                        lab_list.append((sheet_obj.cell(i, m)).value)

    #     # Other
    #     l1 = ["Customer Labs", "Partner Labs", "CSAT", "Customer Probes", "Other", "Early Access", "VAS", "IOT", "FOA", "Delivery", "Transition"]
    #     l2 = ["2 - Submitted", "3 - Shipped / Setup / Waiting for Customer", "4 - Active"]
    #     if (cell_obj.value) in (l1):
    #         for k in range(1, max_col + 1):
    #             #print(cell_obj.value)
    #             if (sheet_obj.cell(i, k).value in l2):
    #                 for m in range(1, max_col + 1):
    #                     el.append((sheet_obj.cell(i, m)).value)
    # #print("other list",el)
# Create excel
workbook = xlsxwriter.Workbook("C:/Users/akalleda/PycharmProjects\excelsfilter/" + b + '.xlsx')  # Destination

# The workbook object is then used to add new
# worksheet via the add_worksheet() method.
#Trial Pipeline
worksheet = workbook.add_worksheet("Trial Pipeline")
kl=0
for kl in range(0, max_col + 1):
    # print(sheet_obj.cell(1,q+1).value)
    #worksheet.write(0, q, sheet_obj.cell(1, q + 1).value)
    if kl in [0, 1, 2]:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
    elif kl == 3:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 1, "Week")
        worksheet.write(0, kl + 2, "Month")
        worksheet.write(0, kl + 3, "Year")
    elif kl == 9:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 4, "Create Week")
        worksheet.write(0, kl + 5, "Create Month")
        worksheet.write(0, kl + 6, "Create Year")

    elif kl in [4, 5, 6, 7, 8]:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
    elif kl in [10, 11, 12, 13, 14, 15, 16, 17, 18]:
        worksheet.write(0, kl + 6, sheet_obj.cell(1, kl + 1).value)
# cell_obj = sheet_obj.cell(i, column = j)
row = 1
# print (len(l))
div18 = len(l) / 18
print(int(div18))
for a in range(0, int(div18)):
    for cl in range(0, 18):
        if cl == 3:
            worksheet.write(row, cl, l[cl])
            date_time_obj = datetime.datetime.strptime(l[cl], '%m/%d/%Y')
            worksheet.write(row, cl + 1, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 2, date_time_obj.date().month)
            worksheet.write(row, cl + 3, date_time_obj.date().isocalendar().year)

        elif cl in [4, 5, 6, 7, 8]:
            worksheet.write(row, cl + 3, l[cl])
        elif cl == 9:
            worksheet.write(row, cl + 3, l[cl])
            date_time_obj = datetime.datetime.strptime(l[cl], '%m/%d/%Y')
            worksheet.write(row, cl + 4, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 5, date_time_obj.date().month)
            worksheet.write(row, cl + 6, date_time_obj.date().isocalendar().year)
        elif cl in [10, 11, 12, 13, 14, 15, 16, 17]:
            worksheet.write(row, cl + 6, l[cl])
        else:
            worksheet.write(row, cl, l[cl])
        cl += 1
    del l[0:18]
    row += 1
# # other
# worksheet = workbook.add_worksheet("other")
# for kl in range(0, max_col + 1):
#     worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
# row = 1
# di18 = len(el) / 18
# print(int(di18))
# for a in range(0, int(di18)):
#     for cl in range(0, 18):
#         worksheet.write(row, cl, el[cl])
#     del el[0:18]
#     row += 1
# pipeline
worksheet = workbook.add_worksheet("Pipeline")
kl=0
for kl in range(0, max_col + 1):
    # worksheet.write(0, kl, sheet_obj.cell(1,kl+1).value)
    if kl in [0, 1, 2]:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
    elif kl == 3:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 1, "Week")
        worksheet.write(0, kl + 2, "Month")
        worksheet.write(0, kl + 3, "Year")
    elif kl == 9:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 4, "Create Week")
        worksheet.write(0, kl + 5, "Create Month")
        worksheet.write(0, kl + 6, "Create Year")

    elif kl in [4, 5, 6, 7, 8]:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
    elif kl in [10, 11, 12, 13, 14, 15, 16, 17, 18]:
        worksheet.write(0, kl + 6, sheet_obj.cell(1, kl + 1).value)

row = 1
di18 = len(pl) / 18
print(int(di18))
# stage=['0 - Concept / Interested','1 - Planning','2 - Submitted']
for a in range(0, int(di18)):
    for cl in range(0, 18):
        if cl == 3:
            worksheet.write(row, cl, pl[cl])
            date_time_obj = datetime.datetime.strptime(pl[cl], '%m/%d/%Y')
            worksheet.write(row, cl + 1, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 2, date_time_obj.date().month)
            worksheet.write(row, cl + 3, date_time_obj.date().isocalendar().year)

        elif cl in [4, 5, 6, 7, 8]:
            worksheet.write(row, cl + 3, pl[cl])
        elif cl == 9:
            worksheet.write(row, cl + 3, pl[cl])
            date_time_obj = datetime.datetime.strptime(pl[cl], '%m/%d/%Y')
            # print('week:', date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 4, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 5, date_time_obj.date().month)
            worksheet.write(row, cl + 6, date_time_obj.date().isocalendar().year)

        elif cl in [10, 11, 12, 13, 14, 15, 16, 17]:
            worksheet.write(row, cl + 6, pl[cl])
        else:
            worksheet.write(row, cl, pl[cl])
        cl += 1

    del pl[0:18]
    row += 1
# Active
worksheet = workbook.add_worksheet("Active")
kl=0
for kl in range(0, max_col + 1):
    if kl in [0, 1, 2]:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
    elif kl == 3:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 1, "Week")
        worksheet.write(0, kl + 2, "Month")
        worksheet.write(0, kl + 3, "Year")
    elif kl == 9:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 4, "Create Week")
        worksheet.write(0, kl + 5, "Create Month")
        worksheet.write(0, kl + 6, "Create Year")

    elif kl in [4, 5, 6, 7, 8]:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
    elif kl in [10, 11, 12, 13, 14, 15, 16, 17, 18]:
        worksheet.write(0, kl + 6, sheet_obj.cell(1, kl + 1).value)
row = 1
di18 = len(al) / 18
print(int(di18))
for a in range(0, int(di18)):
    for cl in range(0, 18):
        if cl == 3:
            worksheet.write(row, cl, al[cl])
            date_time_obj = datetime.datetime.strptime(al[cl], '%m/%d/%Y')
            worksheet.write(row, cl + 1, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 2, date_time_obj.date().month)
            worksheet.write(row, cl + 3, date_time_obj.date().isocalendar().year)

        elif cl in [4, 5, 6, 7, 8]:
            worksheet.write(row, cl + 3, al[cl])
        elif cl == 9:
            worksheet.write(row, cl + 3, al[cl])
            date_time_obj = datetime.datetime.strptime(al[cl], '%m/%d/%Y')
            # print('week:', date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 4, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 5, date_time_obj.date().month)
            worksheet.write(row, cl + 6, date_time_obj.date().isocalendar().year)

        elif cl in [10, 11, 12, 13, 14, 15, 16, 17]:
            worksheet.write(row, cl + 6, al[cl])
        else:
            worksheet.write(row, cl, al[cl])
        cl += 1
    del al[0:18]
    row += 1
# Closed
worksheet = workbook.add_worksheet("Closed")
kl=0
for kl in range(0, max_col + 1):
    if kl in [0, 1, 2]:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
    elif kl == 3:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 1, "Week")
        worksheet.write(0, kl + 2, "Month")
        worksheet.write(0, kl + 3, "Year")
    elif kl == 9:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 4, "Create Week")
        worksheet.write(0, kl + 5, "Create Month")
        worksheet.write(0, kl + 6, "Create Year")

    elif kl in [4, 5, 6, 7, 8]:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
    elif kl in [10, 11, 12, 13, 14, 15, 16, 17, 18]:
        worksheet.write(0, kl + 6, sheet_obj.cell(1, kl + 1).value)
row = 1
di18 = len(closed_list) / 18
print(int(di18))
for a in range(0, int(di18)):
    for cl in range(0, 18):
        if cl == 3:
            worksheet.write(row, cl, closed_list[cl])
            date_time_obj = datetime.datetime.strptime(closed_list[cl], '%m/%d/%Y')
            worksheet.write(row, cl + 1, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 2, date_time_obj.date().month)
            worksheet.write(row, cl + 3, date_time_obj.date().isocalendar().year)

        elif cl in [4, 5, 6, 7, 8]:
            worksheet.write(row, cl + 3, closed_list[cl])
        elif cl == 9:
            worksheet.write(row, cl + 3, closed_list[cl])
            date_time_obj = datetime.datetime.strptime(closed_list[cl], '%m/%d/%Y')
            # print('week:', date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 4, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 5, date_time_obj.date().month)
            worksheet.write(row, cl + 6, date_time_obj.date().isocalendar().year)

        elif cl in [10, 11, 12, 13, 14, 15, 16, 17]:
            worksheet.write(row, cl + 6, closed_list[cl])
        else:
            worksheet.write(row, cl, closed_list[cl])
        cl += 1
    del closed_list[0:18]
    row += 1
# New Trial
worksheet = workbook.add_worksheet("New Trial")
kl=0
for kl in range(0, max_col + 1):
    #worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
    if kl in [0, 1, 2]:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
    elif kl == 3:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 1, "Week")
        worksheet.write(0, kl + 2, "Month")
        worksheet.write(0, kl + 3, "Year")
    elif kl == 9:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 4, "Create Week")
        worksheet.write(0, kl + 5, "Create Month")
        worksheet.write(0, kl + 6, "Create Year")

    elif kl in [4,5, 6, 7, 8]:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
    elif kl in [10, 11, 12, 13, 14, 15, 16, 17, 18]:
        worksheet.write(0, kl + 6, sheet_obj.cell(1, kl + 1).value)
row = 1
di18 = len(newtrial_list) / 18
print(int(di18))
for a in range(0, int(di18)):
    for cl in range(0, 18):

        if cl == 3:
        #worksheet.write(row, cl, newtrial_list[cl])
#----------------------------------------------------------------------------
            worksheet.write(row, cl, newtrial_list[cl])
            date_time_obj = datetime.datetime.strptime(newtrial_list[cl], '%m/%d/%Y')
            worksheet.write(row, cl + 1, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 2, date_time_obj.date().month)
            worksheet.write(row, cl + 3, date_time_obj.date().isocalendar().year)

        elif cl in [4, 5, 6, 7, 8]:
            worksheet.write(row, cl + 3, newtrial_list[cl])
        elif cl == 9:
            worksheet.write(row, cl + 3, newtrial_list[cl])
            date_time_obj = datetime.datetime.strptime(newtrial_list[cl], '%m/%d/%Y')
            worksheet.write(row, cl + 4, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 5, date_time_obj.date().month)
            worksheet.write(row, cl + 6, date_time_obj.date().isocalendar().year)
            #print("cl value",cl)
        elif cl in [10, 11, 12, 13, 14, 15, 16, 17]:
            worksheet.write(row, cl + 6, newtrial_list[cl])
        else:
            worksheet.write(row, cl, newtrial_list[cl])
    cl += 1

#------------------
    del newtrial_list[0:18]
    row += 1
# Lab Trial
worksheet = workbook.add_worksheet("Customer Labs")
kl=0
for kl in range(0, max_col + 1):
    if kl in [0, 1, 2]:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
    elif kl == 3:
        worksheet.write(0, kl, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 1, "Week")
        worksheet.write(0, kl + 2, "Month")
        worksheet.write(0, kl + 3, "Year")
    elif kl == 9:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
        worksheet.write(0, kl + 4, "Create Week")
        worksheet.write(0, kl + 5, "Create Month")
        worksheet.write(0, kl + 6, "Create Year")

    elif kl in [4, 5, 6, 7, 8]:
        worksheet.write(0, kl + 3, sheet_obj.cell(1, kl + 1).value)
    elif kl in [10, 11, 12, 13, 14, 15, 16, 17, 18]:
        worksheet.write(0, kl + 6, sheet_obj.cell(1, kl + 1).value)


row = 1
di18 = len(lab_list) / 18
print(int(di18))
for a in range(0, int(di18)):
    for cl in range(0, 18):
        if cl == 3:
            worksheet.write(row, cl, lab_list[cl])
            date_time_obj = datetime.datetime.strptime(lab_list[cl], '%m/%d/%Y')
            worksheet.write(row, cl + 1, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 2, date_time_obj.date().month)
            worksheet.write(row, cl + 3, date_time_obj.date().isocalendar().year)

        elif cl in [4, 5, 6, 7, 8]:
            worksheet.write(row, cl + 3, lab_list[cl])
        elif cl == 9:
            worksheet.write(row, cl + 3, lab_list[cl])
            date_time_obj = datetime.datetime.strptime(lab_list[cl], '%m/%d/%Y')
            # print('week:', date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 4, date_time_obj.date().isocalendar().week)
            worksheet.write(row, cl + 5, date_time_obj.date().month)
            worksheet.write(row, cl + 6, date_time_obj.date().isocalendar().year)

        elif cl in [10, 11, 12, 13, 14, 15, 16, 17]:
            worksheet.write(row, cl + 6, lab_list[cl])
        else:
            worksheet.write(row, cl, lab_list[cl])
        cl += 1

    del lab_list[0:18]
    row += 1
workbook.close()
##Delete entries older than 2 weeks--------------------
# workbook object is created
sheet_list=["Trial Pipeline","Pipeline","Active","Closed","New Trial","Customer Labs"]
sheet=0
for sheet in sheet_list:
    print(sheet)
    for a in range(0,20):
        path1 = "C:/Users/akalleda/PycharmProjects/excelsfilter/Trial.xlsx" #new sheet
        wb_obj = openpyxl.load_workbook(path1)
        sheet_obj = wb_obj[sheet]
        max_col = sheet_obj.max_column
        max_row = sheet_obj.max_row
        #l =[]
        #b="Customer Probes"
        #print("week",datetime.datetime.now().isocalendar().week)
        for i in range(2, max_row+1):
            cell_obj = sheet_obj.cell(i,14)
            #print(cell_obj.value)
            cell_obj_year=sheet_obj.cell(i,16)
            #print("year",cell_obj_year.value)
            try:
                #print(int(cell_obj.value))
                #if(cell_obj_year>2021):

                    #print(int(cell_obj.value)>(datetime.datetime.now().isocalendar().week - 3) , "and " ,int(cell_obj.value) < (datetime.datetime.now().isocalendar().week + 1))
                    if int(cell_obj.value)>(datetime.datetime.now().isocalendar().week - 3) and int(cell_obj.value) < (datetime.datetime.now().isocalendar().week + 1) and int(cell_obj_year.value)==2021: #update year manually so that you get the results of that year
                            #print(cell_obj.value)
                            print("after IF---------------------------------",i)
                    else:

                        sheet_obj.delete_rows(i,1)
                        #print("else" ,i)
            except ValueError:
                #print("ValueError?????????", i)
                #sheet_obj.delete_rows(i, 1)
                pass
            except TypeError:
                #print("TypeError?????????", i)
                #sheet_obj.delete_rows(i, 1)
                pass
        wb_obj.save(path1)


#sheet_list=["Trial Pipeline","other","Pipeline","Active","Closed","New Trial","Customer Labs"]
i=0
#Delete an existing excel with name: final_sorted_sheet.xlsx

if os.path.exists("C:/Users/akalleda/PycharmProjects/excelsfilter/"+"final_sorted_sheet.xlsx"):

    os.remove("C:/Users/akalleda/PycharmProjects/excelsfilter/final_sorted_sheet.xlsx")
# Create excel
wb=xlsxwriter.Workbook("C:/Users/akalleda/PycharmProjects/excelsfilter/"+"final_sorted_sheet.xlsx")
wb.close()

for i in sheet_list:
    sort_workbook=pandas.read_excel("C:/Users/akalleda/PycharmProjects/excelsfilter/Trial.xlsx",sheet_name=i)
    result = sort_workbook.sort_values('Region')
    #result=sort_workbook.drop(sort_workbook.index[i])
    with pandas.ExcelWriter("C:/Users/akalleda/PycharmProjects/excelsfilter/final_sorted_sheet.xlsx",mode="a",engine="openpyxl",) as writer:result.to_excel(writer,sheet_name=i,index=False)

# print(l)
